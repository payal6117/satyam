<?php require("view/header.php"); ?>


    <!-- -----------------------  Car page  -------------------------------------
---------------------------------------------------------- -->
<section class="common_section car_section popular_car_section " id="fleet" 
    style="margin-top: 10rem;">
    <div class="top_side">

        <!-- <div class="d_flex top_head" >
            <div>
                <h4>Popular Rental Servises</h4>
                <h1>Popular Car</h1>
            </div>
            <div class="common_btn popular_car_btn">
                <a href="#" type="submit" class="btn_link  text-dark fw-bolder fs-4 ">View all</a>
            </div>
        </div> -->
    
        <div class="d_grid ">

            <div class="item box_shadow">
                <a href="#">
                <img src="./img/a3d52961-ab21-4f5f-9b48-e9b7c09bc8ba.jpg" alt="">
                    <p>Ertiga</p>
                </a>
                <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  2000 Day -
                <i class="fa fa-inr" aria-hidden="true"></i> 14 / km</h5>
               
               <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>
            
            <div class="item box_shadow">
                <a href="#">
                <img src="./img/a3d52961-ab21-4f5f-9b48-e9b7c09bc8ba.jpg" alt="">
                    <p>Scorpio</p>
                </a>
                <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  2000 Day -
                    <i class="fa fa-inr" aria-hidden="true"></i> 15 / km</h5>
               
               <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>
            
            <div class="item box_shadow">
            <a href="#">
            <img src="./img/2a60d82d-6dd9-430a-b84a-5e172aa68134.jpg" alt="">
                    <p class="common_sec_content"> VW Vento</p>
                </a>
                <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  1600 Day -
                    <i class="fa fa-inr" aria-hidden="true"></i> 12 / km</h5>
                <div class="">
                    <a href="#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>
    
            <div class="item box_shadow">
            <a href="#">
                    <img src="./img/66d71174-954f-4bb8-94e0-10aac7ce2ccc.jpg" alt="">
                    <p class="common_sec_content"> Crysta innova</p>
                </a>
                <h5 class="common_sec_content">Rent<i class="fa fa-inr" aria-hidden="true"></i>  2400 Day -<i class="fa fa-inr" aria-hidden="true"></i> 17 / km</h5>
                

                <div class="">
                    <a href="#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>

            <div class="item box_shadow">
                <a href="#">
                <img src="./img/a3d52961-ab21-4f5f-9b48-e9b7c09bc8ba.jpg" alt="">
                    <p>Ertiga</p>
                </a>
                <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  2000 Day -
                <i class="fa fa-inr" aria-hidden="true"></i> 14 / km</h5>
               
               <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>
            
            <div class="item box_shadow">
                <a href="#">
                <img src="./img/a3d52961-ab21-4f5f-9b48-e9b7c09bc8ba.jpg" alt="">
                    <p>Scorpio</p>
                </a>
                <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  2000 Day -
                    <i class="fa fa-inr" aria-hidden="true"></i> 15 / km</h5>
               
               <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>
            
            <div class="item box_shadow">
            <a href="#">
            <img src="./img/2a60d82d-6dd9-430a-b84a-5e172aa68134.jpg" alt="">
                    <p class="common_sec_content"> VW Vento</p>
                </a>
                <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  1600 Day -
                    <i class="fa fa-inr" aria-hidden="true"></i> 12 / km</h5>
                <div class="">
                    <a href="#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>
    
            <div class="item box_shadow">
            <a href="#">
                    <img src="./img/66d71174-954f-4bb8-94e0-10aac7ce2ccc.jpg" alt="">
                    <p class="common_sec_content"> Crysta innova</p>
                </a>
                <h5 class="common_sec_content">Rent<i class="fa fa-inr" aria-hidden="true"></i>   2400 Day -<i class="fa fa-inr" aria-hidden="true"></i> 17 / km</h5>
                

                <div class="">
                    <a href="#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>
            
            <!-- <div class="item box_shadow">
                <a href="#">
                    <img src="./img/2a60d82d-6dd9-430a-b84a-5e172aa68134.jpg" alt="">
                    <p></p>
                </a>
               <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  200 Day-<i class="fa fa-inr" aria-hidden="true"></i> 18 / km</h5>
                 <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>
    
            <div class="item box_shadow">
                <a href="#">
                    <img src="./img/66d71174-954f-4bb8-94e0-10aac7ce2ccc.jpg" alt="">
                    <p></p>
                </a>
               <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  200 Day-<i class="fa fa-inr" aria-hidden="true"></i> 18 / km</h5>
                 <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>

            <div class="item box_shadow">
                <a href="#">
                    <img src="./img/66d71174-954f-4bb8-94e0-10aac7ce2ccc.jpg" alt="">
                    <p></p>
                </a>
               <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  200 Day-<i class="fa fa-inr" aria-hidden="true"></i> 18 / km</h5>
                 <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>

            <div class="item box_shadow">
                <a href="#">
                    <img src="./img/66d71174-954f-4bb8-94e0-10aac7ce2ccc.jpg" alt="">
                    <p></p>
                </a>
               <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  200 Day-<i class="fa fa-inr" aria-hidden="true"></i> 18 / km</h5>
                 <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>

            <div class="item box_shadow">
                <a href="#">
                    <img src="./img/66d71174-954f-4bb8-94e0-10aac7ce2ccc.jpg" alt="">
                    <p></p>
                </a>
               <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  200 Day-<i class="fa fa-inr" aria-hidden="true"></i> 18 / km</h5>
                 <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div>

            <div class="item box_shadow">
                <a href="#">
                    <img src="./img/66d71174-954f-4bb8-94e0-10aac7ce2ccc.jpg" alt="">
                    <p></p>
                </a>
               <h5>Rent<i class="fa fa-inr" aria-hidden="true"></i>  200 Day-<i class="fa fa-inr" aria-hidden="true"></i> 18 / km</h5>
                 <div class="">
                    <a href="./#contact" type="submit" class="btn_link  text-dark fw-bolder fs-4 
                    common_btn popular_car_btn common_sec_content">Book Now</a>
                </div>
            </div> -->
        </div>
    
    </div>
    </section>

    <script src="../../satyamtravel/js/scriptmin.js"></script>






    
