<footer class="common_section footer " id="#footer">
        <div class="d_grid">
           <div class="footer_item item"> 
            <img src="./img/logo.png" alt=""  class="mb_3">
 
            <p class="mb_3 compn_text">
                Choose Satyam Travel Car Rental  Services ,
                 We give you the hassle free car rental service, leaving behind the joy of riding at ease. Car Rental Service provides cars on rent in many cities </p>

            <ul class="socials mb_3 ">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
             </ul>
           </div>


           <div class="footer_item item footer_nav_menu ">
                <div class="footer_nav_menu ">
                    <h1 class="">Quick Links</h1>
                    <ul class="f-menu ">
                        <li><a href="./index.php">Home</a></li>
                        <li><a href="./#about">About Us</a></li>
                        <li><a href="./#fleet">Our Fleet</a></li>
                        <li><a href="./#gallery">gallary</a></li>
                        <li><a href="./#foter_adress">Contact</a></li>
                    </ul>
                </div>
           </div>
           <div class="footer_item item" id="foter_adress"> 
                <h1 class="">GET IN TOUCH</h1>

                <div class="get_in_touch">
                    <div class="ofc_item mb_3">
                            <p>
                                <span>Address : <br> </span>
                                Kanhaiya Kumar, sbi officer colony Rd no -3, Bailey Rd, near Mahima mandir, Rukanpura, Patna, Bihar 
                                <br>
                                    PIN : 800025
                            </p>
                    </div>

                    <div class="ofc_item mb_3">
                            <a href="#" class="gmail"> <span>Email:</span> kumarisakshi150905@gmail.com</a>
                    </div>

                    <div class="ofc_item mb_3">
                        <a href="#" class="gmail"> <span>Call: </span>+91 73523 88282</a>
                    </div>
                </div>

           

        </div>
        <div class="item map_address footer_item ">

        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14391.861065410927!2d85.0726921!3d25.6060704!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x971ff330d3be941!2sSatyam%20Travel%20-%20Car%20Rental%20Service%20Provider!5e0!3m2!1sen!2sin!4v1647166795229!5m2!1sen!2sin"  width="90%" height="380" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
               
        </div>
           </div>

           <!-- <span class="copyright"><p>@</p></span> -->
        </div>
    </footer>
</section>

     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>

<script src="./js/scriptmin.js"></script>
</body>
</html>