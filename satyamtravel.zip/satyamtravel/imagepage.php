<?php require("view/header.php"); ?>

  


    <section class="image_main_section">

        <h1>Gallery</h1>
        <div class="galry_content">
            <div class="item">
                <img src="./img/1.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/2.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/3.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/4.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/5.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/6.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/7.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/8.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/9.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/10.jpeg" alt="" class="gallery_img">
            </div>

            <div class="item">
                <img src="./img/11.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/12.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/13.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/14.jpeg" alt="" class="gallery_img">
            </div>
            <div class="item">
                <img src="./img/15.jpeg" alt="" class="gallery_img">
            </div>
        </div>
    </section>
    
    <script src="../../satyamtravel/js/scriptmin.js"></script>