//navbar
// const navbar = document.querySelector('.sticky');
// window.onscroll = () => {
//     if (window.scrollY > 10) {
//         navbar.classList.add('nav-active');
//     } else {
//         navbar.classList.remove('nav-active');
//     }
// };

// counter
$(document).ready(function(){
    $(".counter").counterUp({
        delay:10,
        time:1000
    })
});